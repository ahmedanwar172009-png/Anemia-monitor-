# Anemia Monitor AI — MVP (v0.1)

## Build & install
1. Install Android Studio (Koala+), File > Open > this folder. Let Gradle sync (needs internet once; JitPack is used for usb-serial-for-android).
2. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
3. Copy APK to tablet, allow "install unknown apps", install. (Or enable USB debugging and press Run.)

## Arduino
Open arduino/anemia_monitor/anemia_monitor.ino, install libraries SparkFun MAX3010x + LiquidCrystal_I2C, upload.
Wiring: MAX30102 & LCD on A4/A5 (I2C), GSR SIG -> A0. Baud in sketch (9600) must match the app's choice.

## Use
Connect Nano to tablet via USB-OTG -> accept USB permission -> Users tab: add user -> Measure tab: Start/Stop.
Stop saves the session averages to SQLite. Hb is NOT estimated (no validated model yet).

## Status
Done: USB serial (auto-detect, permission, 9600/115200, reconnect), parsing, live charts, quality/sensor messages,
users + SQLite history + compare + delete, AR/EN. Not done yet: ML pipeline, local AI assistant, PDF report.
