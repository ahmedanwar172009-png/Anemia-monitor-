// Libraries: SparkFun MAX3010x, LiquidCrystal_I2C
// Wiring: MAX30102 SDA/SCL -> A4/A5, LCD I2C (0x27) same bus, GSR SIG -> A0
// Output (1/s): D,<hr>,<spo2>,<gsr>,<ir>   (-1 = invalid; ir=-1 => MAX30102 missing)
#include <Wire.h>
#include "MAX30105.h"
#include "spo2_algorithm.h"
#include <LiquidCrystal_I2C.h>

MAX30105 sensor;
LiquidCrystal_I2C lcd(0x27, 16, 2);
uint16_t irBuf[100], redBuf[100];
int32_t spo2, hr; int8_t vSpo2, vHr;
bool sensorOk = false;

void setup() {
  Serial.begin(9600);  // must match the baud chosen in the app
  lcd.init(); lcd.backlight(); lcd.print("Anemia Monitor");
  sensorOk = sensor.begin(Wire, I2C_SPEED_FAST);
  if (sensorOk) {
    sensor.setup(60, 4, 2, 100, 411, 4096);
    for (byte i = 0; i < 100; i++) {
      while (!sensor.available()) sensor.check();
      redBuf[i] = sensor.getRed(); irBuf[i] = sensor.getIR(); sensor.nextSample();
    }
  }
}

void loop() {
  long ir = -1; hr = -1; spo2 = -1;
  if (sensorOk) {
    for (byte i = 25; i < 100; i++) { redBuf[i-25] = redBuf[i]; irBuf[i-25] = irBuf[i]; }
    for (byte i = 75; i < 100; i++) {
      while (!sensor.available()) sensor.check();
      redBuf[i] = sensor.getRed(); irBuf[i] = sensor.getIR(); sensor.nextSample();
    }
    ir = irBuf[99];
    maxim_heart_rate_and_oxygen_saturation(irBuf, 100, redBuf, &spo2, &vSpo2, &hr, &vHr);
    if (!vHr) hr = -1;
    if (!vSpo2) spo2 = -1;
  } else delay(1000);
  int gsr = analogRead(A0);
  Serial.print("D,"); Serial.print(hr); Serial.print(','); Serial.print(spo2);
  Serial.print(','); Serial.print(gsr); Serial.print(','); Serial.println(ir);
  lcd.setCursor(0, 0); lcd.print("HR:"); lcd.print(hr); lcd.print(" O2:"); lcd.print(spo2); lcd.print("   ");
  lcd.setCursor(0, 1); lcd.print("GSR:"); lcd.print(gsr); lcd.print("      ");
}
