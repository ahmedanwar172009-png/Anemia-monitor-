package com.anemia.monitor

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel

/** One parsed line from Arduino. hr/spo2 null = invalid reading. ir<0 = MAX30102 missing. */
data class Sample(val hr: Float?, val spo2: Float?, val gsr: Int, val ir: Long)

class MainVM(app: Application) : AndroidViewModel(app) {
    private val db = Db(app)
    var conn by mutableStateOf(ConnState.DISCONNECTED); private set
    var baud by mutableIntStateOf(9600); private set
    var measuring by mutableStateOf(false); private set
    var last by mutableStateOf<Sample?>(null); private set
    var lastTime by mutableStateOf<Long?>(null); private set
    val live = mutableStateListOf<Sample>()
    val users = mutableStateListOf<User>()
    var current by mutableStateOf<User?>(null); private set
    val history = mutableStateListOf<Meas>()
    private val session = ArrayList<Sample>()

    private val serial = SerialManager(app, ::onLine, { conn = it; if (it != ConnState.CONNECTED) last = null })

    init { refreshUsers(); serial.start() }

    private fun onLine(line: String) {
        val p = line.split(',')
        if (p.size != 5 || p[0] != "D") return           // ignore anything not in protocol
        val hr = p[1].toFloatOrNull(); val sp = p[2].toFloatOrNull()
        val gsr = p[3].toIntOrNull() ?: return; val ir = p[4].toLongOrNull() ?: return
        val s = Sample(hr?.takeIf { it in 30f..220f }, sp?.takeIf { it in 70f..100f }, gsr, ir)
        last = s; lastTime = System.currentTimeMillis()
        if (measuring) { live.add(s); if (live.size > 120) live.removeAt(0); session.add(s) }
    }

    fun setBaud(b: Int) { baud = b; serial.setBaud(b) }

    fun start() { if (current == null) return; live.clear(); session.clear(); measuring = true }

    fun stop() {
        measuring = false
        val u = current ?: return
        if (session.isEmpty()) return
        fun avg(v: List<Float>) = if (v.isEmpty()) null else v.average()
        db.addMeas(u.id, System.currentTimeMillis(),
            avg(session.mapNotNull { it.hr }), avg(session.mapNotNull { it.spo2 }),
            if (session.any { it.gsr in 6..1017 }) session.filter { it.gsr in 6..1017 }.map { it.gsr.toFloat() }.average() else null,
            session.size)
        session.clear(); refreshHistory()
    }

    fun refreshUsers() { users.clear(); users.addAll(db.users()); if (current == null) users.firstOrNull()?.let { select(it) } }
    fun addUser(name: String, age: Int) { db.addUser(name.trim(), age); refreshUsers() }
    fun select(u: User) { current = u; refreshHistory() }
    fun deleteUser(u: User) { db.deleteUser(u.id); if (current?.id == u.id) current = null; history.clear(); refreshUsers() }
    fun refreshHistory() { history.clear(); current?.let { history.addAll(db.measurements(it.id)) } }
    fun deleteMeas(m: Meas) { db.deleteMeas(m.id); refreshHistory() }

    override fun onCleared() { serial.stop() }
}
