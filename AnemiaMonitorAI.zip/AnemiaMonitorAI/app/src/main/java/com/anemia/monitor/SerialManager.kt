package com.anemia.monitor

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager

enum class ConnState { DISCONNECTED, NO_PERMISSION, CONNECTED, ERROR }

/** All callbacks are delivered on the main thread. */
class SerialManager(
    context: Context,
    private val onLine: (String) -> Unit,
    private val onState: (ConnState) -> Unit
) {
    private val ctx = context.applicationContext
    private val usb = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
    private val main = Handler(Looper.getMainLooper())
    private val ACTION_PERM = "com.anemia.monitor.USB_PERMISSION"
    private var port: UsbSerialPort? = null
    private var io: SerialInputOutputManager? = null
    private val buf = StringBuilder()
    private var registered = false
    var baud = 9600

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PERM -> connect()
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> connect()
                UsbManager.ACTION_USB_DEVICE_DETACHED -> { close(); post(ConnState.DISCONNECTED) }
            }
        }
    }

    private val listener = object : SerialInputOutputManager.Listener {
        override fun onNewData(data: ByteArray) {
            val text = String(data, Charsets.US_ASCII)
            main.post {
                buf.append(text)
                while (true) {
                    val idx = buf.indexOf("\n")
                    if (idx < 0) break
                    val line = buf.substring(0, idx).trim()
                    buf.delete(0, idx + 1)
                    if (line.isNotEmpty()) onLine(line)
                }
                if (buf.length > 512) buf.clear()
            }
        }
        override fun onRunError(e: Exception) {
            close(); post(ConnState.ERROR)
            main.postDelayed({ connect() }, 2000)
        }
    }

    private fun post(s: ConnState) = main.post { onState(s) }

    fun start() {
        if (!registered) {
            val f = IntentFilter().apply {
                addAction(ACTION_PERM)
                addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
                addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            }
            ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
            registered = true
        }
        connect()
    }

    fun stop() {
        if (registered) { ctx.unregisterReceiver(receiver); registered = false }
        close()
    }

    fun setBaud(b: Int) { baud = b; close(); connect() }

    fun connect() {
        if (port != null) return
        val driver = UsbSerialProber.getDefaultProber().findAllDrivers(usb).firstOrNull()
        if (driver == null) { post(ConnState.DISCONNECTED); return }
        val dev: UsbDevice = driver.device
        if (!usb.hasPermission(dev)) {
            val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
            val pi = PendingIntent.getBroadcast(ctx, 0, Intent(ACTION_PERM).setPackage(ctx.packageName), flags)
            usb.requestPermission(dev, pi)
            post(ConnState.NO_PERMISSION); return
        }
        val conn = usb.openDevice(dev)
        if (conn == null) { post(ConnState.ERROR); return }
        try {
            val p = driver.ports[0]
            p.open(conn)
            p.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            p.setDTR(true); p.setRTS(true)
            port = p
            io = SerialInputOutputManager(p, listener).also { it.start() }
            buf.clear()
            post(ConnState.CONNECTED)
        } catch (e: Exception) {
            close(); post(ConnState.ERROR)
            main.postDelayed({ connect() }, 2000)
        }
    }

    private fun close() {
        io?.listener = null; io?.stop(); io = null
        try { port?.close() } catch (_: Exception) {}
        port = null
    }
}
