package com.anemia.monitor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class User(val id: Long, val name: String, val age: Int)
data class Meas(val id: Long, val userId: Long, val ts: Long, val hr: Double?, val spo2: Double?, val gsr: Double?, val n: Int)

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "anemia.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER NOT NULL)")
        d.execSQL("CREATE TABLE measurements(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ts INTEGER NOT NULL, hr REAL, spo2 REAL, gsr REAL, n INTEGER NOT NULL)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun addUser(name: String, age: Int): Long = writableDatabase.insert("users", null,
        ContentValues().apply { put("name", name); put("age", age) })

    fun users(): List<User> = readableDatabase.rawQuery("SELECT id,name,age FROM users ORDER BY id", null).use { c ->
        buildList { while (c.moveToNext()) add(User(c.getLong(0), c.getString(1), c.getInt(2))) }
    }

    fun deleteUser(id: Long) {
        writableDatabase.delete("measurements", "user_id=?", arrayOf(id.toString()))
        writableDatabase.delete("users", "id=?", arrayOf(id.toString()))
    }

    fun addMeas(userId: Long, ts: Long, hr: Double?, spo2: Double?, gsr: Double?, n: Int) {
        val v = ContentValues().apply {
            put("user_id", userId); put("ts", ts); put("n", n)
            if (hr != null) put("hr", hr) else putNull("hr")
            if (spo2 != null) put("spo2", spo2) else putNull("spo2")
            if (gsr != null) put("gsr", gsr) else putNull("gsr")
        }
        writableDatabase.insert("measurements", null, v)
    }

    fun measurements(userId: Long): List<Meas> = readableDatabase.rawQuery(
        "SELECT id,user_id,ts,hr,spo2,gsr,n FROM measurements WHERE user_id=? ORDER BY ts DESC",
        arrayOf(userId.toString())).use { c ->
        buildList {
            while (c.moveToNext()) add(Meas(c.getLong(0), c.getLong(1), c.getLong(2),
                if (c.isNull(3)) null else c.getDouble(3),
                if (c.isNull(4)) null else c.getDouble(4),
                if (c.isNull(5)) null else c.getDouble(5), c.getInt(6)))
        }
    }

    fun deleteMeas(id: Long) { writableDatabase.delete("measurements", "id=?", arrayOf(id.toString())) }
}
