package com.anemia.monitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

private val Blue = Color(0xFF1565C0)

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Color(0xFF42A5F5))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF5F9FF)) { App(vm) }
            }
        }
    }
}

private fun fmt(ts: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ts))

@Composable
fun App(vm: MainVM) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Text(stringResource(R.string.app_name), fontSize = 22.sp, color = Color.White,
            modifier = Modifier.fillMaxWidth().background(Blue).padding(16.dp))
        TabRow(selectedTabIndex = tab) {
            listOf(R.string.tab_measure, R.string.tab_history, R.string.tab_users).forEachIndexed { i, s ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(s)) })
            }
        }
        when (tab) { 0 -> MeasureScreen(vm); 1 -> HistoryScreen(vm); else -> UsersScreen(vm) }
    }
}


@Composable
fun MeasureScreen(vm: MainVM) {
    val s = vm.last
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val st = when (vm.conn) {
            ConnState.CONNECTED -> R.string.st_connected
            ConnState.NO_PERMISSION -> R.string.st_permission
            ConnState.ERROR -> R.string.st_error
            ConnState.DISCONNECTED -> R.string.st_disconnected
        }
        Card(Modifier.fillMaxWidth()) { Text(stringResource(st), Modifier.padding(16.dp), fontSize = 18.sp,
            color = if (vm.conn == ConnState.CONNECTED) Color(0xFF2E7D32) else Color(0xFFC62828)) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.baud), Modifier.align(androidx.compose.ui.Alignment.CenterVertically))
            listOf(9600, 115200).forEach { b ->
                FilterChip(selected = vm.baud == b, onClick = { vm.setBaud(b) }, label = { Text("$b") })
            }
        }
        vm.current?.let { Text("${stringResource(R.string.selected)}: ${it.name} (${it.age})") }
            ?: Text(stringResource(R.string.need_user), color = Color(0xFFC62828))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { vm.start() }, enabled = !vm.measuring && vm.current != null && vm.conn == ConnState.CONNECTED) { Text(stringResource(R.string.start)) }
            OutlinedButton(onClick = { vm.stop() }, enabled = vm.measuring) { Text(stringResource(R.string.stop)) }
        }

        // Sensor status + signal quality (derived only from real data)
        val q = when {
            s == null -> R.string.q_nodata
            s.ir < 0 -> R.string.q_nomax
            s.ir < 20000 -> R.string.q_nofinger
            s.ir < 50000 -> R.string.q_weak
            else -> R.string.q_good
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("${stringResource(R.string.quality)}: ${stringResource(q)}", fontSize = 16.sp)
            if (s != null && (s.gsr <= 5 || s.gsr >= 1018)) Text(stringResource(R.string.q_nogsr), color = Color(0xFFC62828))
        } }

        ValueCard(stringResource(R.string.hr), s?.hr?.let { "%.0f".format(it) })
        ValueCard(stringResource(R.string.spo2), s?.spo2?.let { "%.0f".format(it) })
        ValueCard(stringResource(R.string.gsr), s?.gsr?.takeIf { it in 6..1017 }?.toString())
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text(stringResource(R.string.hb), fontSize = 14.sp)
            Text(stringResource(R.string.hb_na), fontSize = 16.sp, color = Color.Gray)
        } }
        Text("${stringResource(R.string.last_reading)}: ${vm.lastTime?.let { fmt(it) } ?: stringResource(R.string.none)}")

        Chart(stringResource(R.string.hr), vm.live.map { it.hr })
        Chart(stringResource(R.string.spo2), vm.live.map { it.spo2 })
        Chart(stringResource(R.string.gsr), vm.live.map { if (it.gsr in 6..1017) it.gsr.toFloat() else null })
        Text(stringResource(R.string.disclaimer), fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
fun ValueCard(label: String, value: String?) = Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
        Text(label, fontSize = 14.sp)
        Text(value ?: stringResource(R.string.none), fontSize = 32.sp, color = Blue)
    }
}

@Composable
fun Chart(title: String, values: List<Float?>) {
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
        Text(title, fontSize = 13.sp)
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val v = values.filterNotNull()
            if (v.size < 2) return@Canvas
            val mn = v.min(); val mx = v.max(); val r = (mx - mn).takeIf { it > 0f } ?: 1f
            val path = Path(); var started = false
            values.forEachIndexed { i, y ->
                if (y == null) { started = false; return@forEachIndexed }
                val px = size.width * i / (values.size - 1).coerceAtLeast(1)
                val py = size.height - (y - mn) / r * size.height * 0.9f - size.height * 0.05f
                if (!started) { path.moveTo(px, py); started = true } else path.lineTo(px, py)
            }
            drawPath(path, Blue, style = Stroke(width = 3f))
        }
    } }
}

@Composable
fun HistoryScreen(vm: MainVM) {
    val h = vm.history
    if (h.isEmpty()) { Text(stringResource(R.string.no_records), Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(h.size) { i ->
            val m = h[i]; val prev = h.getOrNull(i + 1)
            fun d(a: Double?, b: Double?) = if (a != null && b != null) " (%+.1f)".format(a - b) else ""
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text(fmt(m.ts), fontSize = 16.sp, color = Blue)
                Text("HR: ${m.hr?.let { "%.1f".format(it) } ?: "—"}${if (prev != null) d(m.hr, prev.hr) else ""}")
                Text("SpO2: ${m.spo2?.let { "%.1f".format(it) } ?: "—"}${if (prev != null) d(m.spo2, prev.spo2) else ""}")
                Text("GSR: ${m.gsr?.let { "%.1f".format(it) } ?: "—"}${if (prev != null) d(m.gsr, prev.gsr) else ""}")
                Text("${stringResource(R.string.samples)}: ${m.n}", fontSize = 12.sp, color = Color.Gray)
                if (prev != null) Text(stringResource(R.string.vs_prev), fontSize = 11.sp, color = Color.Gray)
                TextButton(onClick = { vm.deleteMeas(m) }) { Text(stringResource(R.string.delete), color = Color(0xFFC62828)) }
            } }
        }
    }
}

@Composable
fun UsersScreen(vm: MainVM) {
    var name by remember { mutableStateOf("") }; var age by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(name, { name = it }, label = { Text(stringResource(R.string.name)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(age, { age = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.age)) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { vm.addUser(name, age.toInt()); name = ""; age = "" },
            enabled = name.isNotBlank() && (age.toIntOrNull() ?: 0) in 1..120) { Text(stringResource(R.string.add_user)) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.users.size) { i ->
                val u = vm.users[i]
                Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${u.name} (${u.age})", Modifier.weight(1f).align(androidx.compose.ui.Alignment.CenterVertically))
                    if (vm.current?.id == u.id) Text(stringResource(R.string.selected), color = Blue, modifier = Modifier.align(androidx.compose.ui.Alignment.CenterVertically))
                    else OutlinedButton(onClick = { vm.select(u) }) { Text(stringResource(R.string.select)) }
                    TextButton(onClick = { vm.deleteUser(u) }) { Text(stringResource(R.string.delete), color = Color(0xFFC62828)) }
                } }
            }
        }
    }
}
